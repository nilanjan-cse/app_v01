Downloaded from: https://www.thecustomdroid.com/how-to-extract-android-payload-bin-file/

Credits go to developer ius: https://github.com/ius

Source: https://gist.github.com/ius/42bd02a5df2226633a342ab7a9c60f15